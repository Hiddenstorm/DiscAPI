class Channel:
    def __init__(self, data):
        self.name = data["name"]